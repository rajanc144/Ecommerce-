const express = require('express');
const router = express.Router();
//const promodel=require(`../models/productModel`);

const mongoose = require('mongoose');

// Define the product schema
const productSchema = new mongoose.Schema({
    name: { type: String, required: true },
    price: { type: Number, required: true },
    description: { type: String },
    seller: { type: String },
    stock: { type: Number, default: 0 },
    noofreviews: { type: Number, default: 0 }
});

// Create the model
const productModel = mongoose.model('Product', productSchema);



router.get('/', async(req, res) => {
   const product= await productModel.find({});
   
    res.json({ success: true, 
        message: 'Products route is working' ,
        product});
});


module.exports = router;
