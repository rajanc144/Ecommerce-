exports.getproducts = (req, res, next) => {
    res.json({
        success: true,
        message: `get products working`,
    });
};

exports.getSingleproducts = (req, res, next) => {
    const { id } = req.params;
    res.json({
        success: true,
        message: `getSingle products working get single id:${id}`,
    });
};
