
const mongoose=require("mongoose");
const connectDtabase = ()=>{
      mongoose.connect(process.env.DB_URL).then((con)=>{
         console.log("mongodb is being connected  to:"+con.connection.host);
      });  
}
module.exports=connectDtabase;