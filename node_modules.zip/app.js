const express = require("express");
const app = express();
const dotenv = require("dotenv");
const path = require("path");
const connectDatabase=require(`./config/connectDatabase`);

// Load environment variables
dotenv.config({ path: path.join(__dirname, "config", "config.env") });

// Import routes
const products = require("./routes/products");
const orders = require("./routes/order");

// Middleware
app.use(express.json()); // Parses incoming JSON requests

// Mount routes
connectDatabase();
app.use('/api/v1/products', products);
app.use('/api/v1/orders', orders);

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server is listening on port ${PORT} in ${process.env.NODE_ENV}`);
    console.log("PORT:", process.env.PORT);
    console.log("NODE_ENV:", process.env.NODE_ENV);
});
app.use((req, res, next) => {
    res.status(404).json({
        success: false,
        message: "Route not found",
    });
});

app.use((req, res, next) => {
    console.log(`Request received: ${req.method} ${req.url}`);
    next();
});


